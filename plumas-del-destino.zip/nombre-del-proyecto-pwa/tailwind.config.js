/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        serif: ['Cormorant Garamond', 'serif'],
      },
      colors: {
        'cosmic-deep-blue': '#0a0e1a',
        'cosmic-text-light': '#e2e8f0',
        'brand-gold': '#FFD700', // Example accent
      }
    },
  },
  plugins: [],
}
