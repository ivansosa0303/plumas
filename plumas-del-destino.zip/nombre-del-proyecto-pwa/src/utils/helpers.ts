// src/utils/helpers.ts

/**
 * Formats a date object or string into a localized, readable format.
 * @param dateInput - The date to format (Date object, ISO string, or timestamp number).
 * @param locale - The locale for formatting (e.g., 'es-ES', 'en-US').
 * @param options - Intl.DateTimeFormatOptions for custom formatting.
 * @returns A string representing the formatted date, or an empty string if input is invalid.
 */
export const formatDate = (
  dateInput: Date | string | number,
  locale: string = 'es-ES', // Default to Spanish for Plumas del Destino
  options?: Intl.DateTimeFormatOptions
): string => {
  try {
    const dateObj = new Date(dateInput);
    if (isNaN(dateObj.getTime())) { // Check for invalid date
      return '';
    }
    const defaultOptions: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      ...options,
    };
    return dateObj.toLocaleDateString(locale, defaultOptions);
  } catch (error) {
    console.error("Error formatting date:", error);
    return '';
  }
};

/**
 * Delays execution for a specified number of milliseconds.
 * @param ms - The number of milliseconds to delay.
 * @returns A promise that resolves after the delay.
 */
export const delay = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Generates a simple unique ID string.
 * Useful for local list keys or temporary IDs. Not cryptographically secure.
 * @returns A string representing a unique ID.
 */
export const generateLocalUniqueId = (): string => {
  return `id_${Math.random().toString(36).substring(2, 11)}_${Date.now().toString(36)}`;
};

/**
 * Shuffles an array in place (Fisher-Yates algorithm) and returns it.
 * @param array - The array to shuffle.
 * @returns The shuffled array.
 */
export function shuffleArray<T>(array: T[]): T[] {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]]; // Swap elements
  }
  return array;
}

/**
 * Capitalizes the first letter of a string.
 * @param str The string to capitalize.
 * @returns The capitalized string.
 */
export const capitalizeFirstLetter = (str: string): string => {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Truncates a string to a maximum length and appends an ellipsis if truncated.
 * @param text The text to truncate.
 * @param maxLength The maximum length of the string (including ellipsis).
 * @returns The truncated string.
 */
export const truncateText = (text: string, maxLength: number): string => {
  if (!text) return '';
  if (text.length <= maxLength) {
    return text;
  }
  return text.substring(0, maxLength - 3) + "...";
};
