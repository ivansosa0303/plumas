// src/utils/validators.ts

/**
 * Validates if a string is a valid email address.
 * @param email - The string to validate.
 * @returns True if the email is valid, false otherwise.
 */
export const isValidEmail = (email: string): boolean => {
  if (typeof email !== 'string' || !email) return false;
  // RFC 5322 general email regex (a common, fairly comprehensive version)
  const emailRegex = new RegExp(
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  );
  return emailRegex.test(email.trim());
};

/**
 * Validates if a password meets basic strength requirements.
 * Example: at least 8 characters.
 * Adjust complexity as needed (e.g., uppercase, number, special char).
 * @param password - The password string to validate.
 * @param minLength - Minimum length of the password.
 * @returns True if the password meets the criteria, false otherwise.
 */
export const isValidPassword = (password: string, minLength: number = 8): boolean => {
  if (typeof password !== 'string' || !password) return false;
  if (password.length < minLength) return false;
  // Add more checks if needed:
  // const hasUpperCase = /[A-Z]/.test(password);
  // const hasLowerCase = /[a-z]/.test(password);
  // const hasNumber = /[0-9]/.test(password);
  // const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  // return hasUpperCase && hasLowerCase && hasNumber && hasSpecialChar;
  return true; // Basic length check for this example
};

/**
 * Checks if a value is empty (null, undefined, empty string, empty array, or empty object with no own properties).
 * @param value - The value to check.
 * @returns True if the value is considered empty, false otherwise.
 */
export const isEmpty = (value: any): boolean => {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string' && value.trim() === '') return true;
  if (Array.isArray(value) && value.length === 0) return true;
  if (typeof value === 'object' && Object.keys(value).length === 0 && value.constructor === Object ) return true;
  return false;
};

/**
 * Validates if a string has a minimum length.
 * @param value - The string to validate.
 * @param minLength - The minimum required length.
 * @returns True if the string's length is greater than or equal to minLength.
 */
export const hasMinLength = (value: string | undefined | null, minLength: number): boolean => {
  if (typeof value !== 'string' || !value) return false;
  return value.trim().length >= minLength;
};

/**
 * Validates if a string does not exceed a maximum length.
 * @param value - The string to validate.
 * @param maxLength - The maximum allowed length.
 * @returns True if the string's length is less than or equal to maxLength.
 */
export const hasMaxLength = (value: string | undefined | null, maxLength: number): boolean => {
  if (typeof value !== 'string' || !value) return true; // Empty or non-string is fine regarding max length
  return value.length <= maxLength;
};

// Example for Plumas del Destino: Reflection text validation
export const isValidReflectionText = (text: string): { valid: boolean; message?: string } => {
  if (!hasMinLength(text, 10)) {
    return { valid: false, message: "Tu reflexión debe tener al menos 10 caracteres." };
  }
  if (!hasMaxLength(text, 5000)) {
    return { valid: false, message: "Tu reflexión no puede exceder los 5000 caracteres." };
  }
  return { valid: true };
};
