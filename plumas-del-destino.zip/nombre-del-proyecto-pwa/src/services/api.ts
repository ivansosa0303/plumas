// Using Vite's import.meta.env for environment variables
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'; // Default to a relative path if not set

interface RequestOptions extends RequestInit {
  // You can define custom options for your API client if needed
  // For example: useAuthToken?: boolean;
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    let errorData;
    try {
      errorData = await response.json();
    } catch (e) {
      // Not a JSON response, or failed to parse
      errorData = { message: response.statusText || 'An unknown network error occurred' };
    }
    const errorMessage = errorData?.message || `HTTP error! Status: ${response.status}`;
    console.error('API Error:', errorMessage, 'URL:', response.url);
    throw new Error(errorMessage);
  }
  // Handle cases where the response might be empty (e.g., 204 No Content)
  const contentType = response.headers.get("content-type");
  if (contentType && contentType.indexOf("application/json") !== -1) {
    return response.json() as Promise<T>;
  }
  return Promise.resolve(undefined as unknown as T); // Or handle as appropriate for non-JSON
}

export const apiClient = {
  get: async <T>(endpoint: string, options?: RequestOptions): Promise<T> => {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {}),
      },
      ...options,
    });
    return handleResponse<T>(response);
  },

  post: async <TResponse, TBody = unknown>(endpoint: string, body: TBody, options?: RequestOptions): Promise<TResponse> => {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {}),
      },
      body: JSON.stringify(body),
      ...options,
    });
    return handleResponse<TResponse>(response);
  },

  put: async <TResponse, TBody = unknown>(endpoint: string, body: TBody, options?: RequestOptions): Promise<TResponse> => {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {}),
      },
      body: JSON.stringify(body),
      ...options,
    });
    return handleResponse<TResponse>(response);
  },

  delete: async <TResponse>(endpoint: string, options?: RequestOptions): Promise<TResponse> => {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {}),
      },
      ...options,
    });
    return handleResponse<TResponse>(response);
  },
};

// Example usage (ensure VITE_API_BASE_URL is set in .env files if needed):
// interface Card { id: string; name: string; }
// async function fetchCards() {
//   try {
//     const cards = await apiClient.get<Card[]>('/cards'); // Assumes API_BASE_URL/cards
//     console.log(cards);
//   } catch (error) {
//     console.error("Failed to fetch cards:", error);
//   }
// }
