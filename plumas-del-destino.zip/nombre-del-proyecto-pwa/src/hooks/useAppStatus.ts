import { useState, useCallback } from 'react';

interface AppStatus {
  isLoading: boolean;
  error: string | null;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearError: () => void;
}

const useAppStatus = (): AppStatus => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setAppError] = useState<string | null>(null);

  const setLoading = useCallback((loading: boolean) => {
    setIsLoading(loading);
  }, []);

  const setError = useCallback((errorMessage: string | null) => {
    setAppError(errorMessage);
    if (errorMessage) {
      console.error("Application Error:", errorMessage);
    }
  }, []);

  const clearError = useCallback(() => {
    setAppError(null);
  }, []);

  return {
    isLoading,
    error,
    setLoading,
    setError,
    clearError,
  };
};

export default useAppStatus;
