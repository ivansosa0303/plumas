import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authService, AuthUser } from '@/services/authService'; // Assuming authService exports AuthUser type

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  signIn: (email: string, pass: string) => Promise<AuthUser | null>;
  signOut: () => Promise<void>;
  signUp: (email: string, pass: string) => Promise<AuthUser | null>; // Added signUp
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true); // Start true to check auth state

  useEffect(() => {
    // Placeholder: Simulate checking auth state on load
    // In a real Firebase app, you would use firebase.auth().onAuthStateChanged here
    console.log('[AuthContext] Checking initial auth state...');
    const initialUser = authService.getCurrentUser(); // Synchronous placeholder from service
    setUser(initialUser);
    setLoading(false);

    // Example of how a listener might be set up in a real app (if authService provided it)
    // const unsubscribe = authService.onAuthStateChanged(currentUser => {
    //   console.log('[AuthContext] Auth state changed:', currentUser);
    //   setUser(currentUser);
    //   setLoading(false);
    // });
    // return () => {
    //   console.log('[AuthContext] Cleaning up auth state listener.');
    //   unsubscribe();
    // };
  }, []);

  const signIn = async (email: string, pass: string): Promise<AuthUser | null> => {
    setLoading(true);
    try {
      const signedInUser = await authService.signInWithEmail(email, pass);
      setUser(signedInUser);
      return signedInUser;
    } catch (error) {
      console.error("[AuthContext] SignIn error:", error);
      setUser(null); // Ensure user is null on error
      throw error; // Re-throw for component to handle
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, pass: string): Promise<AuthUser | null> => {
    setLoading(true);
    try {
      const signedUpUser = await authService.signUpWithEmail(email, pass);
      setUser(signedUpUser); // Optionally auto-sign-in the user upon successful signup
      return signedUpUser;
    } catch (error) {
      console.error("[AuthContext] SignUp error:", error);
      setUser(null);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    setLoading(true);
    try {
      await authService.signOut();
      setUser(null);
    } catch (error) {
      console.error("[AuthContext] SignOut error:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const value = {
    user,
    loading,
    signIn,
    signOut,
    signUp,
  };

  return (
    <AuthContext.Provider value={value}>
      {/* Optionally show a global loader while auth state is initially loading */}
      {/* {loading && <GlobalLoader />} */}
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
