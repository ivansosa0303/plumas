// src/config/index.ts

export const APP_NAME = import.meta.env.VITE_APP_TITLE || 'Plumas del Destino';
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api'; // Example, adjust if not using API
export const DEBUG_MODE = (import.meta.env.VITE_DEBUG_MODE === 'true');

// Plumas del Destino specific constants
export const TOTAL_CARDS = 50; // Example if you have a fixed number of cards
