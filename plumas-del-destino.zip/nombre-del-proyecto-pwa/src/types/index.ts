// src/types/index.ts

// Represents a single "Pluma del Destino" card
export interface CardData {
  id: number;
  symbolicName: string;
  image: string; // Path to the image, e.g., "/images/01.jpg"
  resonantMessage: string;
  intuitiveInterpretation: string;
  openRecognitionNote: string;
  qrContent: {
    guidedMeditation?: {
      title: string;
      duration: string;
      guide: string;
      closure: string;
    };
    reflectionQuestions?: string[];
    linkPhrase?: string;
    microPractice?: string;
  };
  keywords: string[];
}

// Represents a user's journal entry associated with a card
export interface JournalEntry {
  id: string; // Firestore document ID or local unique ID
  userId?: string; // If using authentication
  cardId: number;
  date: string; // ISO 8601 date string
  reflectionText: string;
  // Optional additional fields
  mood?: string; 
  customKeywords?: string[];
}

// For API responses, if any
export interface ApiResponse<T> {
  data: T | null;
  error?: string | null;
  success: boolean;
}

// User type if using authentication
export interface AppUser {
  uid: string;
  email: string | null;
  displayName?: string | null;
}
