import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  labelClassName?: string;
  inputClassName?: string;
  errorClassName?: string;
}

const Input: React.FC<InputProps> = ({
  label,
  id,
  type = 'text',
  error,
  className = '', // For the wrapper div
  labelClassName = '',
  inputClassName = '',
  errorClassName = '',
  ...props
}) => {
  const baseInputStyles = "block w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-md shadow-sm focus:outline-none focus:ring-brand-gold focus:border-brand-gold sm:text-sm text-slate-200 placeholder-slate-500";
  const errorInputStyles = error ? "border-red-500 focus:ring-red-500 focus:border-red-500" : "border-slate-700";

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label htmlFor={id} className={`block text-sm font-medium text-slate-400 mb-1 ${labelClassName}`}>
          {label}
        </label>
      )}
      <input
        id={id}
        type={type}
        className={`${baseInputStyles} ${errorInputStyles} ${inputClassName}`}
        aria-invalid={error ? 'true' : 'false'}
        aria-describedby={error ? `${id}-error` : undefined}
        {...props}
      />
      {error && (
        <p id={`${id}-error`} className={`mt-1 text-xs text-red-400 ${errorClassName}`} role="alert">
          {error}
        </p>
      )}
    </div>
  );
};

export default Input;
