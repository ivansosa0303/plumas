import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-slate-800/50 backdrop-blur-md shadow-lg sticky top-0 z-50">
      <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="text-2xl font-serif-display font-bold text-brand-gold">
          Plumas del Destino
        </div>
        {/* Placeholder for navigation links if needed in the future */}
        <div>
          {/* Example: <a href="#journal" className="text-slate-300 hover:text-brand-gold px-3">Diario</a> */}
        </div>
      </nav>
    </header>
  );
};

export default Header;
