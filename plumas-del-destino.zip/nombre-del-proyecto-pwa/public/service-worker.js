// service-worker.js for Plumas del Destino

const CACHE_NAME = 'plumas-del-destino-cache-v1';
// Lista de archivos del "App Shell" que se cachearán durante la instalación.
const APP_SHELL_FILES = [
  '/',
  '/index.html',
  '/manifest.json',
  // Vite generates hashed assets, so specific JS/CSS files are usually cached at runtime or if their names are static.
  // For a robust App Shell, ensure main entry points and critical static assets are listed.
  // For example, if you have a static main CSS file not generated with a hash by Vite: '/src/styles/globals.css',
  // However, globals.css is typically imported and bundled by Vite.
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/icons/favicon.svg'
  // Add other critical static assets here
];

self.addEventListener('install', event => {
  console.log('[Service Worker] Install: Plumas del Destino');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('[Service Worker] Caching App Shell for Plumas del Destino');
        return cache.addAll(APP_SHELL_FILES);
      })
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  console.log('[Service Worker] Activate: Plumas del Destino');
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('[Service Worker] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
    .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  // Cache-First strategy
  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        if (cachedResponse) {
          return cachedResponse;
        }
        return fetch(event.request).then(networkResponse => {
          // Optionally, cache new requests if they are important (runtime caching)
          // For example, cache assets built by Vite that might not be in APP_SHELL_FILES initially
          if (networkResponse && networkResponse.status === 200 && event.request.method === 'GET') {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then(cache => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        });
      })
      .catch(error => {
        console.error('[Service Worker] Fetch error:', error);
        // Optionally return a fallback page for GET requests
        // if (event.request.mode === 'navigate') {
        //   return caches.match('/offline.html'); // You would need an offline.html file
        // }
      })
  );
});
